import { createRouter, createWebHistory } from 'vue-router'

import About from '../views/About.vue'
import CardsWcag from '../views/Cardswcag.vue'

const routes = [
  {
    path: '/about',
    name: 'about',
    component: About
  },
  {
    path: '/',
    name: 'cardswcag',
    component: CardsWcag
  }
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})

export default router
