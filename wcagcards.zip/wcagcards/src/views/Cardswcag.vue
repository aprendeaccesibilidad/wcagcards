<script setup>
  import { ref, computed, onMounted } from "vue";
  import CompactCard from "../components/WcagCompactCard.vue";
  
  /* ============================================================
     🔹 ESTADO PRINCIPAL
  ============================================================ */
  const criterios = ref([]);
  
  const filtros = ref({
    search: "",
    principio: [],
    nivel: [],
    wcag: [],
    discapacidad: [],
    perfil: []
  });
  
  /* ============================================================
     🔹 CARGA JSON
  ============================================================ */
  onMounted(async () => {
    const archivos = [
      `${import.meta.env.BASE_URL}ListaWCAG1.json`,
      `${import.meta.env.BASE_URL}ListaWCAG2.json`,
      `${import.meta.env.BASE_URL}ListaWCAG3.json`,
      `${import.meta.env.BASE_URL}ListaWCAG4.json`
    ];
  
    try {
      const respuestas = await Promise.all(archivos.map(a => fetch(a)));
      const listas = await Promise.all(respuestas.map(r => r.json()));
      criterios.value = listas.flat();
    } catch (err) {
      console.error("Error cargando JSON:", err);
    }
  });
  
  /* ============================================================
     🔹 NORMALIZAR TEXTO
  ============================================================ */
  const normalize = str =>
    String(str || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
  
  /* ============================================================
     🔹 BÚSQUEDA
  ============================================================ */
  const matchesSearch = criterio => {
    const text = normalize(filtros.value.search);
    if (!text) return true;
  
    const campos = [
      criterio.id,
      criterio.titulo,
      criterio.descripcion,
      criterio.grupo,
      criterio.subgrupo,
      criterio.principio?.titulo,
      criterio.discapacidades?.map(d => d.titulo).join(" "),
      criterio.subcriterios?.map(s => s.titulo).join(" "),
      criterio.subcriterios?.map(s => s.id).join(" ")
    ];
  
    return campos.some(c => normalize(c).includes(text));
  };
  
  /* ============================================================
     🔹 FILTROS AVANZADOS
  ============================================================ */
  const criteriosFiltrados = computed(() =>
    criterios.value.filter(c => {
      const f = filtros.value;
  
      const okPrincipio =
        f.principio.length === 0 || f.principio.includes(c.principio.id);
  
      const okNivel = f.nivel.length === 0 || f.nivel.includes(c.nivel);
  
      const okWcag = f.wcag.length === 0 || f.wcag.includes(c.version);
  
      const okPerfil =
        !f.perfil?.length || c.perfiles?.some(p => f.perfil.includes(p));
  
      const okDiscapacidad =
        f.discapacidad.length === 0 ||
        c.discapacidades?.some(d => f.discapacidad.includes(d.id));
  
      return (
        okPrincipio &&
        okNivel &&
        okWcag &&
        okPerfil &&
        okDiscapacidad &&
        matchesSearch(c)
      );
    })
  );
  
  /* ============================================================
     🔹 AGRUPAR POR PAUTA
  ============================================================ */
  const gruposPorPauta = computed(() => {
    const map = new Map();
  
    criteriosFiltrados.value.forEach(c => {
      const key = c.pauta.id;
  
      if (!map.has(key)) {
        map.set(key, {
          id: c.pauta.id,
          titulo: c.pauta.titulo,
          url: c.pauta.url,
          criterios: []
        });
      }
  
      map.get(key).criterios.push(c);
    });
  
    return Array.from(map.values());
  });
  
  /* ============================================================
     🔹 AGRUPAR PAUTAS POR PRINCIPIO 
  ============================================================ */
  const gruposPorPrincipio = computed(() => {
    const map = new Map();
  
    gruposPorPauta.value.forEach(pauta => {
      const principio = pauta.criterios[0].principio;
  
      if (!map.has(principio.id)) {
        map.set(principio.id, {
          id: principio.id,
          titulo: principio.titulo,
          url: principio.url,
          pautas: []
        });
      }
  
      map.get(principio.id).pautas.push(pauta);
    });
  
    return Array.from(map.values());
  });
  </script>
  
  <!-- ============================================================
       🔹 TEMPLATE
  ============================================================ -->
  <template>
    <div>
  
      <!-- 🔵 HERO SUPERIOR -->
      <section class="hero-wcag">
        <div class="govuk-width-container">
  
          <p class="govuk-heading-l hero-title">Las pautas WCAG de forma fácil</p>
          <p class="govuk-heading-m hero-title">Criterios de la Pautas de Accesibilidad para el Contenido Web (WCAG) vinculadas a la <a href="https://wikiwcag.udl.cat/P%C3%A1gina_principal" target="_blank" class="govuk-link enlaceblanconegro">wikiwcag.udl.cat <span class="govuk-visually-hidden">(se abre en nueva ventana)</span> </a> </p>

          <p class="govuk-heading-s hero-subtitle">
            Utiliza este campo para filtrar lo que estás buscando:
          </p>
  
          <!-- 🔍 BUSCADOR -->
          <div class="filters-row1">
            <label for="search-input" class="govuk-visually-hidden">
              Buscar:
            </label>
            <input
              id="search-input"
              v-model="filtros.search"
              type="text"
              class="govuk-input search-input"
              placeholder="Buscar por criterio, foco, teclado, subtítulos…"
            />
          </div>
  
          <!-- 🔽 FILTROS DESPLEGABLES -->
          <details class="govuk-details filters-container">
            <summary class="govuk-details__summary govuk-heading-m summary-btn">
              <span class="govuk-details__summary-text">Mostrar / ocultar filtros</span>
            </summary>
  
            <!-- PANEL BLANCO DE FILTROS -->
            <div class="govuk-details__text filters-box">
              <div class="filters-row">
  

  
                <!-- ============================================================
                     DISCAPACIDAD CON ICONOS
                ============================================================ -->
                <div class="filter-block">
                  <fieldset class="govuk-fieldset">
                    <legend class="govuk-fieldset__legend filter-title">Discapacidad</legend>
  
                    <div class="govuk-checkboxes">
  
                      <div class="govuk-checkboxes__item icon-checkbox">
                        <input id="blind" value="blind" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.discapacidad">
                        <label for="blind" class="govuk-label govuk-checkboxes__label">
                          <img src="/assets/Sinvision.png" class="checkbox-icon" alt=""> Visual total
                        </label>
                      </div>
  
                      <div class="govuk-checkboxes__item icon-checkbox">
                        <input id="lowvision" value="lowvision" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.discapacidad">
                        <label for="lowvision" class="govuk-label govuk-checkboxes__label">
                          <img src="/assets/Bajavision.png" class="checkbox-icon" alt=""> Baja visión
                        </label>
                      </div>
  
                      <div class="govuk-checkboxes__item icon-checkbox">
                        <input id="colorblind" value="colorblind" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.discapacidad">
                        <label for="colorblind" class="govuk-label govuk-checkboxes__label">
                          <img src="/assets/Daltonismo.png" class="checkbox-icon" alt=""> Daltonismo
                        </label>
                      </div>
  
                      <div class="govuk-checkboxes__item icon-checkbox">
                        <input id="deaf" value="deaf" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.discapacidad">
                        <label for="deaf" class="govuk-label govuk-checkboxes__label">
                          <img src="/assets/Auditiva.png" class="checkbox-icon" alt=""> Auditiva
                        </label>
                      </div>
  
                      <div class="govuk-checkboxes__item icon-checkbox">
                        <input id="cognitive" value="cognitive" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.discapacidad">
                        <label for="cognitive" class="govuk-label govuk-checkboxes__label">
                          <img src="/assets/Cognitiva.png" class="checkbox-icon" alt=""> Cognitiva
                        </label>
                      </div>
  
                      <div class="govuk-checkboxes__item icon-checkbox">
                        <input id="learning" value="learning" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.discapacidad">
                        <label for="learning" class="govuk-label govuk-checkboxes__label">
                          <img src="/assets/LenguajeAprendizaje.png" class="checkbox-icon" alt=""> Lenguaje y aprendizaje
                        </label>
                      </div>
  
                      <div class="govuk-checkboxes__item icon-checkbox">
                        <input id="motor" value="motor" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.discapacidad">
                        <label for="motor" class="govuk-label govuk-checkboxes__label">
                          <img src="/assets/Motriz.png" class="checkbox-icon" alt=""> Motriz
                        </label>
                      </div>
  
                    </div>
                  </fieldset>
                </div>


                <!-- ============================================================
                    PERFIL PROFESIONAL
                ============================================================ -->
                <div class="filter-block">
                  <fieldset class="govuk-fieldset">
                    <legend class="govuk-fieldset__legend filter-title">Perfil</legend>

                    <div class="govuk-checkboxes">

                      <div class="govuk-checkboxes__item">
                        <input 
                          id="perfil-ux" 
                          value="UX" 
                          type="checkbox" 
                          class="govuk-checkboxes__input" 
                          v-model="filtros.perfil"
                        >
                        <label for="perfil-ux" class="govuk-label govuk-checkboxes__label">
                          UX = Diseño UX
                        </label>
                      </div>

                      <div class="govuk-checkboxes__item">
                        <input 
                          id="perfil-ui" 
                          value="UI" 
                          type="checkbox" 
                          class="govuk-checkboxes__input" 
                          v-model="filtros.perfil"
                        >
                        <label for="perfil-ui" class="govuk-label govuk-checkboxes__label">
                          UI = Diseño gráfico/visual
                        </label>
                      </div>

                      <div class="govuk-checkboxes__item">
                        <input 
                          id="perfil-front" 
                          value="Desarrollo" 
                          type="checkbox" 
                          class="govuk-checkboxes__input" 
                          v-model="filtros.perfil"
                        >
                        <label for="perfil-front" class="govuk-label govuk-checkboxes__label">
                          Desarrollador
                        </label>
                      </div>


                      <div class="govuk-checkboxes__item">
                        <input 
                          id="perfil-copy" 
                          value="Contenido" 
                          type="checkbox" 
                          class="govuk-checkboxes__input" 
                          v-model="filtros.perfil"
                        >
                        <label for="perfil-copy" class="govuk-label govuk-checkboxes__label">
                          Creador de Contenido
                        </label>
                      </div>



                    </div>
                  </fieldset>
                </div>

                <!-- ============================================================
                     PRINCIPIO
                ============================================================ -->
                <div class="filter-block">
                  <fieldset class="govuk-fieldset">
                    <legend class="govuk-fieldset__legend filter-title">Principio</legend>
  
                    <div class="govuk-checkboxes">
  
                      <div class="govuk-checkboxes__item">
                        <input id="p1" value="1" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.principio">
                        <label for="p1" class="govuk-label govuk-checkboxes__label">Perceptible</label>
                      </div>
  
                      <div class="govuk-checkboxes__item">
                        <input id="p2" value="2" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.principio">
                        <label for="p2" class="govuk-label govuk-checkboxes__label">Operable</label>
                      </div>
  
                      <div class="govuk-checkboxes__item">
                        <input id="p3" value="3" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.principio">
                        <label for="p3" class="govuk-label govuk-checkboxes__label">Comprensible</label>
                      </div>
  
                      <div class="govuk-checkboxes__item">
                        <input id="p4" value="4" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.principio">
                        <label for="p4" class="govuk-label govuk-checkboxes__label">Robusto</label>
                      </div>
  
                    </div>
                  </fieldset>
                </div>

                <!-- ============================================================
                     WCAG VERSION
                ============================================================ -->
                <div class="filter-block">
                  <fieldset class="govuk-fieldset">
                    <legend class="govuk-fieldset__legend filter-title">WCAG</legend>
  
                    <div class="govuk-checkboxes">
  
                      <div class="govuk-checkboxes__item">
                        <input id="wcag20" value="2.0" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.wcag">
                        <label for="wcag20" class="govuk-label govuk-checkboxes__label">2.0</label>
                      </div>
  
                      <div class="govuk-checkboxes__item">
                        <input id="wcag21" value="2.1" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.wcag">
                        <label for="wcag21" class="govuk-label govuk-checkboxes__label">2.1</label>
                      </div>
  
                      <div class="govuk-checkboxes__item">
                        <input id="wcag22" value="2.2" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.wcag">
                        <label for="wcag22" class="govuk-label govuk-checkboxes__label">2.2</label>
                      </div>
  
                    </div>
                  </fieldset>
                  <br/><br/>

                <!-- ============================================================
                     NIVEL
                ============================================================ -->
                  <fieldset class="govuk-fieldset">
                    <legend class="govuk-fieldset__legend filter-title">Nivel</legend>
  
                    <div class="govuk-checkboxes">
  
                      <div class="govuk-checkboxes__item">
                        <input id="nivel-a" value="A" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.nivel">
                        <label for="nivel-a" class="govuk-label govuk-checkboxes__label">A</label>
                      </div>
  
                      <div class="govuk-checkboxes__item">
                        <input id="nivel-aa" value="AA" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.nivel">
                        <label for="nivel-aa" class="govuk-label govuk-checkboxes__label">AA</label>
                      </div>
  
                      <div class="govuk-checkboxes__item">
                        <input id="nivel-aaa" value="AAA" type="checkbox" class="govuk-checkboxes__input" v-model="filtros.nivel">
                        <label for="nivel-aaa" class="govuk-label govuk-checkboxes__label">AAA</label>
                      </div>
  
                    </div>
                  </fieldset>
                </div>
  

  
  
              </div>
            </div>
          </details>
  
        </div>
      </section>
  
      <!-- ⚪ CONTENIDO BLANCO -->
      <main class="content-wcag">
        <div class="govuk-width-container">
          
          
          <section
          v-for="principio in gruposPorPrincipio"
          :key="principio.id"
          class="principio-block"
        >

          <!-- 🔵 TÍTULO DEL PRINCIPIO -->
          <h2 class="govuk-heading-l principio-title">
            Principio {{ principio.id }} — {{ principio.titulo }}
          </h2>

          <!-- 🔽 PAUTAS DE ESE PRINCIPIO -->
          <section
            v-for="grupo in principio.pautas"
            :key="grupo.id"
            class="pauta-block"
          >
            <header class="pauta-header">
              <h2 class="govuk-heading-m pauta-heading">
                <a :href="grupo.url" target="_blank" class="govuk-link">
                  {{ grupo.id }} — {{ grupo.titulo }}
                </a>
              </h2>

              <p class="pauta-subtitle">{{ grupo.criterios.length }} criterios</p>
            </header>

            <div class="cards-grid">
              <CompactCard
                v-for="c in grupo.criterios"
                :key="c.id"
                :criterio="c"
              />
            </div>
          </section>

        </section>



  
        </div>
      </main>
  
    </div>
  </template>
  
  <!-- ============================================================
       🔹 ESTILOS
  ============================================================ -->
  <style scoped>
  .hero-wcag {
    background: #1d70b8;
    color: white;
    padding: 32px 0 28px;
  }
  .hero-title,
  .hero-subtitle {
    color: white;
  }
  
/* ============================================================
   🔍 BUSCADOR
============================================================ */
.search-input {
  background: #ffffff;
  border: 3px solid #0b0c0c;
  padding: 12px;
  width: 100%;
  font-size: 1.5em;
  margin-bottom: 16px;
}

  /* ============================================================
   🔽 DETALLES / SUMMARY
============================================================ */
.summary-btn {
  margin-top: 8px;
  margin-bottom: 12px;
  cursor: pointer;
}


/* Hace que la flecha del summary esté siempre visible */

.govuk-details__summary::before {
  margin-right: 12px !important;
  opacity: 1 !important; /* visible siempre */
}

.govuk-details__summary-text {
  color: white !important;
} 

.govuk-details__summary:focus,
.govuk-details__summary:focus-visible {
  background: #ffdd00 !important;
  outline: 3px solid #0b0c0c !important;
}

.govuk-details__summary:focus .govuk-details__summary-text,
.govuk-details__summary:focus-visible .govuk-details__summary-text {
  color: #0b0c0c !important;
}

  .filters-box {
    background: white;
    padding: 16px;
    border-radius: 6px;
  }
  /* ============================================================
   🟦 GRID DE FILTROS — 4 COLUMNAS EN DESKTOP
============================================================ */
.filters-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr); /* 🔥 4 columnas */
  gap: 24px;
}

/* Breakpoint tablet: 2 columnas */
@media (max-width: 900px) {
  .filters-row {
    grid-template-columns: repeat(2, 1fr);
  }
}

/* Breakpoint móvil: 1 columna */
@media (max-width: 600px) {
  .filters-row {
    grid-template-columns: 1fr;
  }
}
  
  .filter-block {
    min-width: 220px;
  }
  
  .checkbox-icon {
    width: 22px;
    height: 22px;
    margin-right: 6px;
    vertical-align: middle;
  }
  
  .content-wcag {
    background: white;
    padding: 40px 0;
  }
  
  .cards-grid {
    display: grid;
    gap: 24px;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  }
  
  .pauta-block {
    background: white;
    border: 1px solid #ddd;
    border-radius: 6px;
    padding: 24px;
    margin-bottom: 40px;
  }
  
  .pauta-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 16px;
  }


  .enlaceblanconegro {
  color: white !important;
} 

.enlaceblanconegro:focus,
.enlaceblanconegro:focus-visible {
  background: #ffdd00 !important;
  outline: 3px solid #0b0c0c !important;
  color: black !important;

}


  </style>
  