<template>
  <!-- MAIN CONTENT BLOCK -->
  <main class="govuk-width-container govuk-!-margin-top-6 govuk-!-margin-bottom-9">

    <h1 class="govuk-heading-l">Sobre el proyecto WCAG Cards</h1>

    <p class="govuk-body">
      WCAG Cards es una web de referencia que presenta los criterios de
      accesibilidad de las <strong>pautas WCAG 2.2</strong> en un formato visual,
      filtrable y mostrando la información de forma comprensible.
    </p>

    <p class="govuk-body">
    Inspirado en el proyecto de <a href="https://guia-wcag.com/es/" class="govuk-link" target="_blank">
      Guia WCAG </a> hemos vinculado toda la información a la <a href="https://wikiwcag.udl.cat/P%C3%A1gina_principal" class="govuk-link" target="_blank">  wiki-wcag </a>, creada por el grupo de investigación <a href="https://www.griho.udl.cat/en/" class="govuk-link" target="_blank"> GRIHO </a> de la <a href="https://www.udl.cat/ca/" class="govuk-link" target="_blank">Universitat de Lleida</a>.
      <br/><br/>
      Responsable del proyecto: <strong><a href="https://www.linkedin.com/in/afra-pascual-almenara/" class="govuk-link" target="_blank">Afra Pascual Almenara </a></strong>.
    </p>


    <p class="govuk-body">
      El proposito principal es faciltar la comprensión de los criterios WCAG y cada targeta integra información clave:
    </p>

    <ul class="govuk-list govuk-list--bullet">
      <li>Discapacidades relacionadas (con iconos)</li>
      <li>Nivel de conformidad</li>
      <li>Descripción del criterio</li>
      <li>Subcriterios y enlaces directos a documentación ampliada</li>
      <li>Perfil responsable de aplicar el criterio</li>
    </ul>

    <h2 class="govuk-heading-m govuk-!-margin-top-6">¿Qué pretende resolver?</h2>

    <p class="govuk-body">
      La documentación oficial WCAG es muy extensa y a menudo difícil de navegar.
      Este proyecto facilita:
    </p>

    <ul class="govuk-list govuk-list--bullet">
      <li>localizar rápidamente criterios relevantes;</li>
      <li>entender cómo afectan a distintos perfiles de discapacidad;</li>
      <li>explicar accesibilidad en contextos formativos y profesionales;</li>
      <li>mostrar los perfiles responsables de accesibilidad.</li>
    </ul>

    <h2 class="govuk-heading-m govuk-!-margin-top-6">Referencias oficiales</h2>

    <ul class="govuk-list govuk-list--bullet">
      <li>
        <a href="https://www.w3.org/WAI/standards-guidelines/wcag/"
           class="govuk-link" target="_blank">
          W3C – WCAG Overview
        </a>
      </li>
      <li>
        <a href="https://www.w3.org/TR/WCAG22/"
           class="govuk-link" target="_blank">
          W3C – WCAG 2.2
        </a>
      </li>
      <li>
        <a href="https://wikiwcag.udl.cat"
           class="govuk-link" target="_blank">
          Wiki WCAG UdL
        </a>
      </li>
    </ul>

    <p class="govuk-body govuk-!-margin-top-6">
      Este proyecto forma parte de una iniciativa académica del grupo de investigación GRIHO de la Universidad de Lleida
      para impulsar la accesibilidad digital y el diseño inclusivo.
    </p>

  </main>
</template>

<script setup>
</script>

<style scoped>
/* Mantiene la anchura recomendada GOV.UK */
.govuk-width-container {
  max-width: 960px;
}
</style>
