<script setup>
  import { ref, computed, onMounted } from "vue";
  import CompactCard from "../components/WcagCompactCard.vue";
  
  /* ============================================================
     🔹 ESTADO PRINCIPAL
  ============================================================ */
  const criterios = ref([]);
  
  const filtros = ref({
    search: "",
    principio: [],
    nivel: [],
    wcag: [],
    discapacidad: []
  });
  
  /* ============================================================
     🔹 CARGA JSON
  ============================================================ */
  onMounted(async () => {
    const archivos = [
      `${import.meta.env.BASE_URL}ListaWCAG1.json`,
      `${import.meta.env.BASE_URL}ListaWCAG2.json`,
      `${import.meta.env.BASE_URL}ListaWCAG3.json`,
      `${import.meta.env.BASE_URL}ListaWCAG4.json`
    ];
  
    try {
      const respuestas = await Promise.all(archivos.map(a => fetch(a)));
      const listas = await Promise.all(respuestas.map(r => r.json()));
      criterios.value = listas.flat();
    } catch (err) {
      console.error("Error cargando JSON:", err);
    }
  });
  
  /* ============================================================
     🔹 NORMALIZAR TEXTO
  ============================================================ */
  const normalize = str =>
    String(str || "")
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
  
  /* ============================================================
     🔹 BÚSQUEDA
  ============================================================ */
  const matchesSearch = criterio => {
    const text = normalize(filtros.value.search);
    if (!text) return true;
  
    const campos = [
      criterio.id,
      criterio.titulo,
      criterio.descripcion,
      criterio.grupo,
      criterio.subgrupo,
      criterio.principio?.titulo,
      criterio.discapacidades?.map(d => d.titulo).join(" "),
      criterio.subcriterios?.map(s => s.titulo).join(" "),
      criterio.subcriterios?.map(s => s.id).join(" ")
    ];
  
    return campos.some(c => normalize(c).includes(text));
  };
  
  /* ============================================================
     🔹 FILTROS AVANZADOS
  ============================================================ */
  const criteriosFiltrados = computed(() =>
    criterios.value.filter(c => {
      const f = filtros.value;
  
      const okPrincipio = f.principio.length === 0 || f.principio.includes(c.principio.id);
      const okNivel = f.nivel.length === 0 || f.nivel.includes(c.nivel);
      const okWcag = f.wcag.length === 0 || f.wcag.includes(c.version);
      const okDiscapacidad =
        f.discapacidad.length === 0 ||
        c.discapacidades?.some(d => f.discapacidad.includes(d.id));
  
      return okPrincipio && okNivel && okWcag && okDiscapacidad && matchesSearch(c);
    })
  );
  
  /* ============================================================
     🔹 AGRUPAR POR PAUTA
  ============================================================ */
  const gruposPorPauta = computed(() => {
    const map = new Map();
  
    criteriosFiltrados.value.forEach(c => {
      const key = c.pauta.id;
  
      if (!map.has(key)) {
        map.set(key, {
          id: c.pauta.id,
          titulo: c.pauta.titulo,
          criterios: []
        });
      }
  
      map.get(key).criterios.push(c);
    });
  
    return Array.from(map.values());
  });
  
  /* ============================================================
     🔹 TOGGLE PILLS
  ============================================================ */
  function togglePill(group, value) {
    const arr = filtros.value[group];
    filtros.value[group] = arr.includes(value)
      ? arr.filter(v => v !== value)
      : [...arr, value];
  }
  </script>
  
  <!-- ============================================================
       🔹 TEMPLATE
  ============================================================ -->
  <template>
    <div>
  
      <!-- 🔵 HERO SUPERIOR -->
      <section class="hero-wcag">
        <div class="govuk-width-container">
  
          <h1 class="govuk-heading-l hero-title">Guía WCAG — Cards Interactivas</h1>
          <p class="govuk-heading-m hero-subtitle">
            Utiliza este campo para filtrar lo que estás buscando:
          </p>
  
          <!-- 🔍 BUSCADOR -->
          <div class="filters-row">
            <input
              v-model="filtros.search"
              type="text"
              class="govuk-input search-input"
              placeholder="Buscar por criterio, foco, teclado, subtítulos…"
            />
          </div>
  
          <!-- 🔽 FILTROS DESPLEGABLES -->
          <details class="govuk-details filters-container">
            <summary class="govuk-details__summary govuk-heading-m summary-btn">
              <span class="govuk-details__summary-text">
                Mostrar / ocultar filtros
              </span>
            </summary>
  
            <!-- PANEL BLANCO DE FILTROS -->
            <div class="govuk-details__text filters-box">
  
              <div class="filters-row">
  
                <!-- PRINCIPIO -->
                <div class="filter-block">
                  <p class="filter-title">Principio</p>
                  <div class="pill-row">
                    <button @click="togglePill('principio','1')" :class="['pill', filtros.principio.includes('1') ? 'active':'']">Perceptible</button>
                    <button @click="togglePill('principio','2')" :class="['pill', filtros.principio.includes('2') ? 'active':'']">Operable</button>
                    <button @click="togglePill('principio','3')" :class="['pill', filtros.principio.includes('3') ? 'active':'']">Comprensible</button>
                    <button @click="togglePill('principio','4')" :class="['pill', filtros.principio.includes('4') ? 'active':'']">Robusto</button>
                  </div>
                </div>
  
                <!-- NIVEL -->
                <div class="filter-block">
                  <p class="filter-title">Nivel</p>
                  <div class="pill-row">
                    <button @click="togglePill('nivel','A')" :class="['pill', filtros.nivel.includes('A') ? 'active':'']">A</button>
                    <button @click="togglePill('nivel','AA')" :class="['pill', filtros.nivel.includes('AA') ? 'active':'']">AA</button>
                    <button @click="togglePill('nivel','AAA')" :class="['pill', filtros.nivel.includes('AAA') ? 'active':'']">AAA</button>
                  </div>
                </div>
  
                <!-- WCAG -->
                <div class="filter-block">
                  <p class="filter-title">WCAG</p>
                  <div class="pill-row">
                    <button @click="togglePill('wcag','2.0')" :class="['pill', filtros.wcag.includes('2.0') ? 'active':'']">2.0</button>
                    <button @click="togglePill('wcag','2.1')" :class="['pill', filtros.wcag.includes('2.1') ? 'active':'']">2.1</button>
                    <button @click="togglePill('wcag','2.2')" :class="['pill', filtros.wcag.includes('2.2') ? 'active':'']">2.2</button>
                  </div>
                </div>
  
                <!-- DISCAPACIDAD -->
                <div class="filter-block">
                  <p class="filter-title">Discapacidad</p>
  
                  <div class="pill-row">
  
                    <button @click="togglePill('discapacidad','blind')" :class="['pill icon-pill', filtros.discapacidad.includes('blind') ? 'active':'']">
                      <img src="/assets/Sinvision.png" alt="" class="pill-icon" /> Visual total
                    </button>
  
                    <button @click="togglePill('discapacidad','lowvision')" :class="['pill icon-pill', filtros.discapacidad.includes('lowvision') ? 'active':'']">
                      <img src="/assets/Bajavision.png" alt="" class="pill-icon" /> Baja visión
                    </button>
  
                    <button @click="togglePill('discapacidad','colorblind')" :class="['pill icon-pill', filtros.discapacidad.includes('colorblind') ? 'active':'']">
                      <img src="/assets/Daltonismo.png" alt="" class="pill-icon" /> Daltonismo
                    </button>
  
                    <button @click="togglePill('discapacidad','deaf')" :class="['pill icon-pill', filtros.discapacidad.includes('deaf') ? 'active':'']">
                      <img src="/assets/Auditiva.png" alt="" class="pill-icon" /> Auditiva
                    </button>
  
                    <button @click="togglePill('discapacidad','cognitive')" :class="['pill icon-pill', filtros.discapacidad.includes('cognitive') ? 'active':'']">
                      <img src="/assets/Cognitiva.png" alt="" class="pill-icon" /> Cognitiva
                    </button>
  
                    <button @click="togglePill('discapacidad','learning')" :class="['pill icon-pill', filtros.discapacidad.includes('learning') ? 'active':'']">
                      <img src="/assets/LenguajeAprendizaje.png" alt="" class="pill-icon" /> Lenguaje y aprendizaje
                    </button>
  
                    <button @click="togglePill('discapacidad','motor')" :class="['pill icon-pill', filtros.discapacidad.includes('motor') ? 'active':'']">
                      <img src="/assets/Motriz.png" alt="" class="pill-icon" /> Motriz
                    </button>
  
                  </div>
                </div>
  
              </div>
            </div>
          </details>
  
        </div>
      </section>
  
      <!-- ⚪ CONTENIDO BLANCO -->
      <main class="content-wcag">
        <div class="govuk-width-container">
  
          <section v-for="grupo in gruposPorPauta" :key="grupo.id" class="pauta-block">
  
            <header class="pauta-header">
              <h2 class="govuk-heading-m pauta-heading">
                {{ grupo.id }} — {{ grupo.titulo }}
              </h2>
              <p class="pauta-subtitle">{{ grupo.criterios.length }} criterios</p>
            </header>
  
            <div class="cards-grid">
              <CompactCard
                v-for="c in grupo.criterios"
                :key="c.id"
                :criterio="c"
              />
            </div>
  
          </section>
  
        </div>
      </main>
  
    </div>
  </template>
  
  <!-- ============================================================
       🔹 ESTILOS — FLEX + ICONOS AUTOMÁTICOS + SIN STICKY
  ============================================================ -->
  <style scoped>
  
  /* ============================================================
     🔵 HERO
  ============================================================ */
  .hero-wcag {
    background: #1d70b8;
    color: white;
    padding: 32px 0 28px;
    border-bottom: 1px solid white;
  }
  
  .hero-title,
  .hero-subtitle {
    color: white;
  }

  .hero-title:focus {
  outline: 3px solid #ffdd00;
  color: black !important;
  box-shadow:
    0 0 0 4px #ffffff,
    0 0 0 7px #1d70b8;
}

  
  .hero-wcag details.govuk-details > summary.govuk-details__summary .govuk-details__summary-text {
  color: #ffffff !important;
}
/* Bloquea hover negro de GOV.UK */
.hero-wcag details.govuk-details > summary.govuk-details__summary:hover,
.hero-wcag details.govuk-details > summary.govuk-details__summary:hover .govuk-details__summary-text {
  color: #ffffff !important;
  text-decoration: none !important;
}

  /* ============================================================
     🔍 BUSCADOR
  ============================================================ */
  .search-input {
    background: #ffffff;
    border: 3px solid #0b0c0c;
    padding: 12px;
    width: 100%;
    margin-bottom: 16px;
  }
  
  /* ============================================================
     🔽 DETALLES / SUMMARY
  ============================================================ */
  .summary-btn {
    margin-top: 8px;
    margin-bottom: 12px;
    cursor: pointer;
  }
  
  .govuk-details__summary::before {
    margin-right: 12px !important;
  }
  
  .govuk-details__summary-text {
    color: white !important;
  }
  
  /* ============================================================
     ⚪ PANEL BLANCO DE FILTROS
  ============================================================ */
  .filters-box {
    background: white;
    padding: 16px;
    border-radius: 6px;
  }

  .filters-contaiers:focus {
  outline: 3px solid #ffdd00;
  color: black !important;
  box-shadow:
    0 0 0 4px #ffffff,
    0 0 0 7px #1d70b8;
}
  
  
  /* ============================================================
     🟦 FILTROS EN FLEX
  ============================================================ */
  .filters-row {
    display: flex;
    flex-wrap: wrap;
    gap: 24px;
  }
  
  .filter-block {
    min-width: 220px;
  }
  
  /* ============================================================
     🟣 PILLS (GENÉRICOS)
  ============================================================ */
  .pill-row {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  }
  
  .pill {
    border: 2px solid #1d70b8;
    background: white;
    border-radius: 14px;
    padding: 4px 12px;
    cursor: pointer;
    font-size: 14px;
  }
  
  .pill.active {
    background: #1d70b8;
    color: white;
  }
  
  /* ============================================================
     👁️ ICON-PILLS (DISCAPACIDAD)
  ============================================================ */
  .icon-pill {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 12px;
  }
  
  .pill-icon {
    width: 20px;
    height: 20px;
    object-fit: contain;
  }
  
  /* ICONOS BLANCOS EN HERO */
  .hero-wcag .pill-icon {
    filter: brightness(0) invert(1);
  }
  
  /* ICONOS NORMALES EN PANEL BLANCO */
  .filters-box .pill-icon {
    filter: none;
  }
  
  /* ============================================================
     ⚪ CONTENIDO BLANCO
  ============================================================ */
  .content-wcag {
    background: white;
    padding: 40px 0;
  }
  
  /* ============================================================
     🟥 CARDS
  ============================================================ */
  .cards-grid {
    display: grid;
    gap: 24px;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  }
  
  .pauta-block {
    background: white;
    border: 1px solid #ddd;
    border-radius: 6px;
    padding: 24px;
    margin-bottom: 40px;
  }
  
  .pauta-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 16px;
  }
  </style>
  