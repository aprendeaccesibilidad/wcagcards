<template>
  <div>
    <!-- ===== HERO DE GOV.UK SOLO PARA ESTA PÁGINA ===== -->
    <header class="cardswcag-hero">
      <div class="govuk-width-container">

        <div class="cardswcag-hero__title-container govuk-heading-m">
          <h1 class="cardswcag-hero__title">
            <span class="cardswcag-hero__intro">
              Consulta los criterios WCAG de forma rápida y visual
            </span>
          </h1>
        </div>

        <!-- Buscador estilo GOV.UK homepage -->
        <div class="cardswcag-hero__search">
          <form @submit.prevent>
            <label class="govuk-label govuk-label--s search-label">
              Buscar
            </label>

            <div class="search-wrapper">
              <input
                type="search"
                class="govuk-input search-input"
                placeholder="Search WCAG..."
                v-model="filtros.search"
              />

              <button class="search-button" type="submit">
                🔍
              </button>
            </div>
          </form>
        </div>

      </div>
    </header>

    <!-- ===== CONTENIDO DE LAS CARDS ===== -->
    <main class="govuk-width-container govuk-!-padding-top-6">
      <!-- aquí van tus filtros y tus cards -->
      <CompactCard v-for="c in criterios" :key="c.id" :criterio="c" />
    </main>
  </div>
</template>

<script setup>
import { ref } from "vue";
import CompactCard from "../components/WcagCompactCard.vue";

const filtros = ref({ search: "" });

const criterios = ref([]); // tu carga real de JSON
</script>

<style scoped>
/* ===== HERO GRANDE GOV.UK SOLO PARA ESTA PÁGINA ===== */

.cardswcag-hero {
  background: #1d70b8;
  color: white;
  padding: 10px 0 50px;
}

.cardswcag-hero__title {
  font-size: 42px;
  font-weight: 200;
  margin-bottom: 10px;
  color: white;

}

.search-label {
  color: white !important;
  margin-bottom: 8px;
}

.search-wrapper {
  display: flex;
  align-items: center;
  background: white;
  border-radius: 4px;
  overflow: hidden;
}

.search-input {
  flex-grow: 1;
  border: none;
  padding: 12px;
  font-size: 18px;
}

.search-input:focus {
  outline: 4px solid #ffdd00;
}

.search-button {
  background: #003078;
  color: white;
  border: none;
  padding: 12px 18px;
  font-size: 18px;
  cursor: pointer;
}
</style>
