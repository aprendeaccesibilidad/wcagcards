import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

// CSS de GOV.UK
import 'govuk-frontend/dist/govuk/govuk-frontend.min.css'

// JS de GOV.UK
//import { initAll } from 'govuk-frontend/dist/govuk/all.mjs'


const app = createApp(App)

app.use(router)

// Monta la app
app.mount('#app')

// Inicializa TODOS los componentes GOV.UK (accordion, tabs, details…)
//initAll()
