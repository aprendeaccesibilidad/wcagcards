<template>
  <div class="govuk-template__body">
    <a href="#main-content" class="govuk-skip-link">
      Saltar al contenido principal
    </a>

    <!-- ============================================================
         🔵 HEADER GOV.UK PERSONALIZADO WCAG-Cards
    ============================================================ -->
    <header class="govuk-header govuk-header--blue" role="banner">
      <div class="govuk-width-container govuk-header__container">

        <!-- LOGO -->
        <h1 class="govuk-header__logo">
          <router-link
            to="/"
            class="govuk-header__link govuk-header__link--homepage"
          >
            <!-- ⭐ LOGO WCAG-Cards ESTILO GOV.UK CROWN-POUR -->


              <!-- Texto WCAG-Cards -->
              <text 
                x="120" 
                y="36" 
                font-size="28" 
                font-weight="700" 
                font-family="Arial, sans-serif"
              >
                WCAG Cards
              </text>
            
          </router-link>
        </h1>

        <!-- BOTÓN MENU (solo móvil) -->
        <button
          class="govuk-header__menu-button"
          @click="menuOpen = !menuOpen"
          :aria-expanded="menuOpen.toString()"
          aria-controls="mobile-menu"
        >
          Menu
        </button>

        <!-- MENÚ DESKTOP -->
        <div class="govuk-header__content desktop-nav ">
          <nav aria-label="Menu principal">
            <ul class="govuk-header__navigation-list">
              <li class="govuk-header__navigation-item">
                <router-link class="govuk-header__link" to="/about">
                  About
                </router-link>
              </li>
            </ul>
          </nav>
        </div>

      </div>

      <!-- MENÚ MÓVIL DESPLEGABLE -->
      <nav 
        v-show="menuOpen"
        id="mobile-menu"
        class="govuk-header__mobile-panel"
        aria-label="Menu móvil"
      >
        <ul class="govuk-header__navigation-list">
          <li class="govuk-header__navigation-item">
            <router-link 
              class="govuk-header__link" 
              to="/about" 
              @click="menuOpen=false"
            >
              About
            </router-link>
          </li>
        </ul>
      </nav>
    </header>

    <!-- ============================================================
         MAIN CONTENT
    ============================================================ -->
    <main id="main-content">
      <slot />
    </main>

    <!-- ============================================================
         FOOTER
    ============================================================ -->
    <footer class="govuk-footer" role="contentinfo">
      <div class="govuk-width-container">
        <div class="govuk-footer__meta govuk-footer__meta-item--grow footer-logos">
          <a href="https://www.udl.cat/ca/" class="govuk-link" target="_blank"><img src="/src/assets/logo-udl.png" alt="Universitat de Lleida" class="footer-logo" /></a>
          <a href="https://www.griho.udl.cat/en/" class="govuk-link" target="_blank"><img src="/src/assets/logo-griho.png" alt="GRIHO Research Group" class="footer-logo" /></a>
          
        </div>

        <div class="govuk-footer__meta">
          <p class="govuk-footer__meta-custom">
            Proyecto académico desarrollado por la <strong><a href="https://www.udl.cat/ca/" class="govuk-link" target="_blank">Universitat de Lleida</a></strong> 
            y el grupo de investigación <strong><a href="https://www.griho.udl.cat/en/" class="govuk-link" target="_blank">GRIHO </a></strong>.
          <br/><br/>
            Responsable del proyecto: <strong><a href="https://www.linkedin.com/in/afra-pascual-almenara/" class="govuk-link" target="_blank">Afra Pascual Almenara </a></strong>.
          </p>

          <p class="govuk-footer__meta-custom">
            WCAG Cards facilita la consulta y comprensión de los criterios 
            <strong>WCAG 2.2</strong>.
          </p>
        </div>

        <div class="govuk-footer__meta">

        <p class="govuk-footer__meta-copyright">
            © {{ new Date().getFullYear() }} UdL — Grupo GRIHO
            <br />
            Última actualización: 8/12/2025
          </p>
        </div>
      </div>
    </footer>

  </div>
</template>

<script setup>
import { ref } from "vue";
const menuOpen = ref(false);
</script>

<style scoped>

/* ============================================================
   🔵 HEADER AZUL GOV.UK
============================================================ */
.govuk-header--blue {
  background-color: #1d70b8;
  padding: 15px 0 20px;
  border-bottom: 1px solid white;
}

.govuk-header--blue .govuk-header__link,
.govuk-header--blue .govuk-header__logotype-text {
  color: white !important;
}

/* ============================================================
   ⭐ WCAG-CARDS LOGO ESTILO GOV.UK CROWN-POUR
============================================================ */
.wcag-logo {
  display: inline-block;
  vertical-align: middle;
  fill: white; /* blanco sobre azul */
}

/* ============================================================
   🔶 FOCUS GOV.UK — AMARILLO + NEGRO
============================================================ */
.govuk-header__link:focus,
.govuk-header__link:focus-visible {
  background-color: #ffdd00 !important;
  outline: 3px solid #0b0c0c !important;
  color: #0b0c0c !important;
}

/* Cambiar SVG a negro durante el foco */
.govuk-header__link:focus .wcag-logo,
.govuk-header__link:focus-visible .wcag-logo {
  fill: #0b0c0c !important;
}

/* ============================================================
   MENU MÓVIL
============================================================ */
.govuk-header__menu-button {
  display: none;
  background: none;
  border: 2px solid white;
  color: white;
  padding: 6px 14px;
  font-size: 18px;
  border-radius: 4px;
  cursor: pointer;
}

.govuk-header__mobile-panel {
  background: #1d70b8;
  padding: 15px 0;
}

@media (max-width: 768px) {
  .desktop-nav { display: none; }
  .govuk-header__menu-button { display: block; }
}

/* 🔥 Alineación perfecta GOV.UK entre LOGO y MENÚ */
.govuk-header__container {
  display: flex;
  align-items: center; /* CENTRA verticalmente logo + menú */
  justify-content: space-between; /* separa logo y navegación */
}
/* ============================================================
   SKIP LINK ACCESIBLE
============================================================ */
.govuk-skip-link {
  position: absolute;
  left: 0;
  top: -40px;
  padding: 8px 16px;
  background: #1d70b8;
  color: white;
  font-weight: bold;
  text-decoration: none;
  z-index: 1000;
}

.govuk-skip-link:focus {
  top: 0;
  outline: 3px solid #ffdd00;
  color: black !important;
}

/* ============================================================
   FOOTER
============================================================ */
.footer-logos {
  display: flex;
  align-items: center;
  gap: 20px;
  margin-bottom: 25px;
}

.footer-logo {
  height: 50px;
  width: auto;
}

</style>
