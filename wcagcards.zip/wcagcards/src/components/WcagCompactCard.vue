<template>
  <article
    class="wcag-card"
    role="region"
    :aria-labelledby="tituloId"
    :class="`principio-${criterio.principio.id}`"
  >

    <!-- 🔹 CABECERA DECORADA + TÍTULO + ICONOS DE DISCAPACIDAD -->
    <div class="wcag-header">
      <div class="wcag-header-pattern"></div>


      <!-- ICONOS DE DISCAPACIDAD EN LA CABECERA -->
      <div class="wcag-avatar-group-header">
        <div
          v-for="d in criterio.discapacidades"
          :key="d.id"
          class="wcag-avatar"
          :aria-label="d.titulo"
        >
          <img :src="d.icon" :alt="d.titulo" />
        </div>
      </div>
    </div>

     
    <!-- 🔹 FOOTER / RESUMEN (AHORA JUSTO DEBAJO DE LA CABECERA) -->
    <div class="wcag-footer govuk-heading-s">
      <div class="wcag-footer-item">
        <p class="wcag-stat-label">Nivel</p>
        <p class="wcag-stat-value">{{ criterio.nivel }}</p>
      </div>
      <div class="wcag-footer-item">
        <p class="wcag-stat-label">WCAG</p>
        <p class="wcag-stat-value">{{ criterio.version }}</p>
      </div>
      <div class="wcag-footer-item">
        <p class="wcag-stat-label">Grupo</p>
        <p class="wcag-stat-value">{{ criterio.grupo }}</p>
      </div>
    </div>





    <!-- TÍTULO DEL CRITERIO -->
    <h3 :id="tituloId" class="wcag-title-header govuk-heading-m">
      <a :href="criterio.url" target="_blank" class="govuk-link">
        {{ criterio.id }}. {{ criterio.titulo }}
        <span class="govuk-visually-hidden">(se abre en nueva ventana)</span>
      </a>
      </h3>

    <!-- 🔹 DESCRIPCIÓN -->
    <div class="wcag-body">
      <p class="wcag-description govuk-body">
        {{ criterio.descripcion }}
      </p>
    </div>

    <!-- 🔹 SUBCRITERIOS (details + summary correctamente ordenados) -->
    <details
      v-if="criterio.subcriterios?.length"
      class="govuk-details wcag-details"
    >
      <summary class="govuk-details__summary wcag-summary govuk-heading-s">
        <span class="govuk-details__summary-text">Subcriterios</span>
      </summary>

      <div class="govuk-details__text wcag-list">
        <ul class="sublist govuk-body-s">
          <li v-for="s in criterio.subcriterios" :key="s.id">
            <a :href="s.url" target="_blank" class="govuk-link">
              {{ s.id }} — {{ s.titulo }}
            <span class="govuk-visually-hidden">(se abre en nueva ventana)</span>
            </a>
          </li>
        </ul>
      </div>
    </details>
    
  <!-- 🔹 PERFILES (usando govuk-tag) -->
  <div class="wcag-perfiles govuk-heading-s">
  <p class="wcag-stat-label ">Perfiles</p>

  <div class="wcag-tags">
    <span
      v-for="p in criterio.perfiles"
      :key="p"
      class="govuk-tag"
      :class="perfilColor(p)"
    >
      {{ p }}
    </span>
  </div>
</div>


  </article>
</template>

<script setup>
import { computed } from "vue";
import { onMounted, nextTick } from 'vue'
import { initAll } from 'govuk-frontend/dist/govuk/all.mjs'

const props = defineProps({
  criterio: { type: Object, required: true }
});

const tituloId = computed(() => `titulo-${props.criterio.id}`);


onMounted(async () => {
  await nextTick()      // asegúrate de que el DOM ya existe
  initAll()             // inicializa acordeón, details, etc.
})

// 🎨 Colores GOV.UK para cada perfil
const perfilColor = (perfil) => {
  const map = {
    UI: "govuk-tag--blue",
    UX: "govuk-tag--yellow",
    "UI/Gráfico": "govuk-tag--pink",
    Contenido: "govuk-tag--purple",
    Desarrollador: "govuk-tag--grey"
  };

  return map[perfil] ?? "govuk-tag--grey";
};
</script>

<style scoped>

/* ============================
   🎨 COLORES POR PRINCIPIO
============================ */
.principio-1 .wcag-header { background: #8BB8F3; }
.principio-2 .wcag-header { background: #85CDA6; }
.principio-3 .wcag-header { background: #F2D77E; }
.principio-4 .wcag-header { background: #C8B2F0; }

/* ============================
   🌟 CARD GENERAL
============================ */
.wcag-card {
  background: white;
  border-radius: 16px;
  overflow: hidden;
  border: 1px solid #d0d0d0;
  transition: box-shadow .2s ease;

  display: flex;
  flex-direction: column; /* la card se organiza verticalmente */
  height: 100%;           /* que todas tengan la misma altura */
}

.wcag-card:hover {
  box-shadow: 0 6px 18px rgba(0,0,0,.15);
}

/* ============================
   🌟 CABECERA
============================ */
.wcag-header {
  height: 65px;
  position: relative;
  padding: 5px 10px;
  color: black;
}

.wcag-title-header {
  position: relative;
  z-index: 3;
  margin: 0.5em 20px;
  color: black;
  font-size: 1.5rem;
  font-weight: 900;
  text-align: left;
  border-bottom: 1px solid #e5e5e5;
}

/* patrón decorativo */
.wcag-header-pattern {
  width: 100%;
  height: 100%;
  opacity: .25;
  position: absolute;
  top: 0;
  left: 0;
  /*
  background-image:
    radial-gradient(circle at 20% 20%, white 10%, transparent 25%),
    radial-gradient(circle at 70% 40%, white 10%, transparent 25%),
    radial-gradient(circle at 40% 70%, white 10%, transparent 25%);
  */
  background-color:black;
    background-size: 120px 120px;
  z-index: 1;
}

/* ============================
   🌟 ICONOS DISCAPACIDAD EN CABECERA
============================ */
.wcag-avatar-group-header {
  position: relative;
  z-index: 3;
  display: flex;
  gap: 10px;
  margin: 5px 0;

}

.wcag-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  overflow: hidden;
  border: 2px solid white;
  background: white;
  display: flex;
  justify-content: center;
  align-items: center;
}

.wcag-avatar img {
  width: 90%;
  height: 90%;
  object-fit: contain;
}

/* ============================
   🌟 FOOTER / RESUMEN (ALINEADO A LA IZQUIERDA)
============================ */
.wcag-footer {
  display: flex;
  justify-content: flex-start;   /* Alinea los bloques a la izquierda */
  gap: 20px;                     /* Espacio entre columnas */
  text-align: left;              /* Alineación interna a la izquierda */
  border-bottom: 1px solid #e5e5e5;
  padding: 0 5px;
  margin: 0;
  background: #fafafa;
}
.wcag-footer p {
  margin: 0.2em 0.1em;   /* Elimina márgenes verticales */
}

.wcag-footer-item {
  flex: 1;                       /* Mantiene 3 columnas equilibradas */
  text-align: left;              /* Texto alineado a la izquierda */
}

.wcag-stat-label {
  font-size: 0.9rem;
  color: #222121;
  text-align: left;
}

.wcag-stat-value {
  font-size: 1.5rem;
  font-weight: 700;
  text-align: left;
}

/* ============================
   🌟 DESCRIPCIÓN
============================ */
.wcag-body {
  padding: 0 20px;
}

.wcag-description {
  margin-top: 5px;
  font-size: 1.2rem;
  line-height: 1.55;
  color: #333;
  text-align: left;
}

/* ============================
   🌟 SUBCRITERIOS
============================ */
.wcag-details {
  padding: 5px 20px;
}

.wcag-summary {
  cursor: pointer;
  font-weight: 700;
  font-size: 1.5rem;
}

.wcag-summary::after {
  margin-left: 8px;
  transition: transform .2s ease;
}

details[open] .wcag-summary::after {
  transform: rotate(90deg);
}

.sublist {
  list-style: none;
  padding-left: 0;
  margin: 0;
}

.sublist li {
  margin-bottom: 5px;
  font-size: 1.5rem;
}

/*
.wcag-perfiles {
  padding: 1px 5px;
  border-bottom: 1px solid #e5e5e5;
  background: #fafafa;
}*/

/* El footer ‘Perfiles’ se quedará siempre abajo */
.wcag-perfiles {
  margin-top: auto; /* ⬅ MÁGICO: lo envía al final */
  padding: 3px 5px;
  border-top: 1px solid #e5e5e5;
  background: #fafafa;
}

.wcag-tags .govuk-tag {
  margin-right: 6px;
  margin-bottom: 6px;
  display: inline-block;
}


</style>
