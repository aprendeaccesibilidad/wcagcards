<template>
  <!-- Layout global GOV.UK envolviendo todas las páginas -->
  <GovUkLayout>
    <router-view />
  </GovUkLayout>
</template>

<script setup>
import GovUkLayout from "./layouts/GovUkLayout.vue"
</script>

<style>
/* GOV.UK recomienda que el body no tenga margin */
body {
  margin: 0;
  padding: 0;
}



</style>
